package com.employee.employee_demo;

public class EmployeeNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2544355350018174050L;

	
public EmployeeNotFoundException(String error){
	super(error);
}


	
}
	
		
	
	
	
	
	


