/*package com.employee.employee_demo;

import org.springframework.stereotype.Component;

@Component
public class EmployeeExceptionResponse {
	
	
	private int code;
	private String message;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	private String error;

	public EmployeeExceptionResponse(String error) {
		super();
		this.setError(error);
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
	
	
	

}
*/